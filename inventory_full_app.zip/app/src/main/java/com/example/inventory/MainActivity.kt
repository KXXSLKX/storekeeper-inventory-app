
package com.example.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.room.Room
import com.example.inventory.db.*

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "inv.db").allowMainThreadQueries().build()
        val dao = db.itemDao()

        setContent {
            var name by remember { mutableStateOf("") }
            var barcode by remember { mutableStateOf("") }
            var quantity by remember { mutableStateOf("0") }

            Scaffold(
                topBar = { TopAppBar(title={ Text("Inventory App") }) }
            ) { pad ->
                Column(Modifier.padding(pad).padding(16.dp)) {
                    TextField(value=name,onValueChange={name=it},label={Text("Name")})
                    TextField(value=barcode,onValueChange={barcode=it},label={Text("Barcode")})
                    TextField(value=quantity,onValueChange={quantity=it},label={Text("Qty")})
                    Button(onClick={
                        dao.insert(Item(name=name, barcode=barcode, quantity=quantity.toInt(), expiry=null))
                    }){ Text("Add") }

                    val all = dao.getAll()
                    all.forEach {
                        Text("${it.name} | ${it.barcode} | ${it.quantity}")
                    }
                }
            }
        }
    }
}
